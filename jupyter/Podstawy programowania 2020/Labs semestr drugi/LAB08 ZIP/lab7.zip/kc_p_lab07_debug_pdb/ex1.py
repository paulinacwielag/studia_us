#!/usr/bin/env python3

filename = __file__
breakpoint()
print(f'path = {filename}')