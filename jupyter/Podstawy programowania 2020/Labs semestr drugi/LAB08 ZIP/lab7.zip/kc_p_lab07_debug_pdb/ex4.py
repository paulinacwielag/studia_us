#!/usr/bin/env python3

import lab7 

filename = __file__
breakpoint()
filename_path = lab7.get_path(filename)
print(f'path = {filename_path}')
